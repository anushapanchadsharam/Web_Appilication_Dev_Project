import React from 'react';
import Slider from 'react-slick';
import ava01 from '../../../assets/images/ava-1.png';
import '../../../styles/slider.css';

const TestimonialSlider = () => {
  const settings = {
    dots: true,
    autoPlay: true,
    infinite: true,
    speed: 1000,
    autoplaySpeed: 3000,
    swipeToSlide: true,
    slidesToShow: 1,
    slidesToScroll: 1,
  };
  return (
    <Slider {...settings}>
      <div>
        <p className='review__text'>
         "The Platform Club ordered a range of stock from Trent Furniture. The furniture was the right fit for our venue, excellent quality, sturdy and durable. The customer service was exceptional in all aspects, especially when helping to decide on the correct furniture and specific measurements for the unique spaces within a brand new venue. We were very pleased with the speed of delivery. We had a scratch on one table which occurred whilst out for delivery, this was replaced the next working day. Excellent service from beginning to end. Amelia Edmondson, courtesy of Matthew Nunn, General Manager, The Platform Club."
        </p>
        <div className='slider__content d-flex align-items-center gap-3'>
          <img src={ava01} alt='avatar' className=' rounded' />
          <h5>Sanduni</h5>
        </div>
      </div>
      
    </Slider>
  );
};

export default TestimonialSlider;
