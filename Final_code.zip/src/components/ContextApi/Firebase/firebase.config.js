const firebaseConfig = {
    apiKey: "AIzaSyBFEdFrSFiw0fKd6p3dWLES_ypQy8nDRMs",
    authDomain: "raja-3e392.firebaseapp.com",
    projectId: "raja-3e392",
    storageBucket: "raja-3e392.appspot.com",
    messagingSenderId: "393623473633",
    appId: "1:393623473633:web:1aff3af36c691ce6cf16a0"
  };

export default firebaseConfig;