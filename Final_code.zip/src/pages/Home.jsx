import React, { useState, useEffect } from 'react';
import Helmet from '../components/Helmet/Helmet.js';
import { Container, Row, Col, ListGroup, ListGroupItem } from 'reactstrap';
import '../styles/hero-section.css';
import { Link } from 'react-router-dom';
import Category from '../components/UI/category/Category.jsx';
import '../styles/home.css';
import featureImg01 from '../assets/images/service-01.png';
import featureImg02 from '../assets/images/service-02.png';
import featureImg03 from '../assets/images/service-03.png';
import products from '../assets/fake-data/products.js';


import foodCategoryImg03 from '../assets/images/bread.png';
import ProductCard from '../components/UI/product-card/ProductCard.jsx';
import whyImg from '../assets/images/location.png';
import networkImg from '../assets/images/network.png';
import TestimonialSlider from '../components/UI/slider/TestimonialSlider.jsx';

const featureData = [
  {
    title: 'Fast Delivery',
    imgUrl: featureImg01,
    desc: 'Enter your address and let us do the rest.',
  },
  {
    title: 'Best Price',
    imgUrl: featureImg02,
    desc: 'For Your Budjet Plans.',
  },
  {
    title: 'Premimum Deals',
    imgUrl: featureImg03,
    desc: 'Super Discounts',
  },
];
const Home = () => {
  const [category, setCategory] = useState('ALL');
  const [allProducts, setAllProducts] = useState(products);
  const [hotPizza, setHotPizza] = useState([]);

  useEffect(() => {
    const filteredPizza = products.filter((item) => item.category === 'Chair');
    const slicePizza = filteredPizza.slice(0, 4);
    setHotPizza(slicePizza);
  }, []);
  useEffect(() => {
    if (category === 'ALL') {
      setAllProducts(products);
    }
    if (category === 'CHAIR') {
      const filteredProducts = products.filter(
        (item) => item.category === 'Chair'
      );
      setAllProducts(filteredProducts);
    }
    if (category === 'SOFA') {
      const filteredProducts = products.filter(
        (item) => item.category === 'Sofa'
      );
      setAllProducts(filteredProducts);
    }
    if (category === 'TABLE') {
      const filteredProducts = products.filter(
        (item) => item.category === 'Table'
      );
      setAllProducts(filteredProducts);
    }
  }, [category]);
  return (
    <Helmet title='Home'>
      <section>
        <Container align='center'>
          <Row>
            <Col lg='12' md='6'>
              <div className='hero__content'>
                <h5 className='mb-3'>
                  Best Price and Quality Products based on Your Budject.
                </h5>
                <h1 className='mb-4 hero__title'>
                  <span>Looking For Best Deal?</span> DiveIN <br /> 
                  
                </h1>

                

                <div className='hero__btns d-flex align-items-center gap-5 mt-4 justify-content-center'>
                <Link to='/foods'>
                  <button className='order__btn d-flex align-items-center justify-content-between'>
                  
                    Order now <i className='ri-arrow-right-s-line'></i>
                  
                  </button>
                </Link>
                  <button className='all__foods-btn'>
                    <Link to='/foods'>See all furnitures</Link>
                  </button>
                </div>
                <div className='hero__service d-flex align-items-center gap-5 mt-5 justify-content-center'>
                  <p className='d-flex align-items-center gap-2'>
                    <span className='shipping__icon'>
                      <i className='ri-car-line'></i>
                    </span>
                  Delivery Available
                  </p>
                  <p className='d-flex align-items-center gap-2'>
                    <span className='shipping__icon'>
                      <i className='ri-shield-check-line'></i>
                    </span>
                    100% secure checkout
                  </p>
                </div>
              </div>
            </Col>
           
          </Row>
        </Container>
      </section>
      <section className='pt-0'>
        <Category />
      </section>

      <section>
        <Container>
          <Row>
            <Col lg='12' className='text-center'>
              
              {/* <h2 className='feature__title'> Just sit back at home</h2> */}
              <h2 className='feature__title'>
                we will <span>take care</span> <br></br>
                your Needs
              </h2>
              <p className='mb-1 mt-4 feature__text'>
              Five Star Customer Google Reviews for Furny Furniture
              </p>
              <p className='mb-1 mt-4 feature__text'>
              Service from start to finish was great, and good quality stools !!
              </p>
              <p className='mb-1 mt-4 feature__text'>
              Excellent service and the new chairs have been well received by the users of our Village Hall.
              </p>

              
            </Col>

            {featureData.map((item, index) => {
              return (
                <Col lg='4' md='6' sm='6' key={index} className='mt-5'>
                  <div className='feature__item text-center px-5 py-3'>
                    <img
                      className='w-25 mb-3'
                      src={item.imgUrl}
                      alt='feature-img'
                    />
                    <h5 className='fw-bold mb-3'>{item.title}</h5>
                    <p>{item.desc}</p>
                  </div>
                </Col>
              );
            })}
          </Row>
        </Container>
      </section>

      <section>
        <Container>
          <Row>
            <Col lg='12' className='text-center'>
              <h2>Popular Furnitures</h2>
            </Col>
            <Col lg='12'>
              <div className='food__category d-flex align-items-center justify-content-center gap-5'>
                <button
                  onClick={() => setCategory('ALL')}
                  className={`all__btn ${
                    category === 'ALL' ? 'foodBtnActive' : ''
                  }`}
                >
                  All
                </button>
                <button
                  onClick={() => setCategory('CHAIR')}
                  className={`d-flex align-items-center gap-2 ${
                    category === 'CHAIR' ? 'foodBtnActive' : ''
                  }`}
                >
                  {/* <img src={foodCategoryImg01} alt='' /> */}
                  Chair
                </button>
                <button
                  onClick={() => setCategory('SOFA')}
                  className={`d-flex align-items-center gap-2 ${
                    category === 'SOFA' ? 'foodBtnActive' : ''
                  }`}
                >
                  {/* <img src={foodCategoryImg02} alt='' /> */}
                  Sofa
                </button>
                <button
                  onClick={() => setCategory('TABLE')}
                  className={`d-flex align-items-center gap-2 ${
                    category === 'TABLE' ? 'foodBtnActive' : ''
                  }`}
                >
                  {/* <img src={foodCategoryImg03} alt='' /> */}
                  Table
                </button>
              </div>
            </Col>

            {allProducts.map((item) => {
              return (
                <Col lg='3' md='4' sm='6' xs='6' key={item.id} className='mt-5'>
                  <ProductCard item={item} />
                </Col>
              );
            })}
          </Row>
        </Container>
      </section>

      <section className='why__choose-us'>
        <Container>
          <Row>
            <Col lg='6' md='6'>
              <img src={whyImg} alt='why-PickFood' className='w-100'></img>
            </Col>
            <Col lg='6' md='6'>
              <div className='why__PickFood'>
                <h2 className='PickFood-title mb-4'>
                  Why <span>Furny?</span>
                </h2>
                <p className='PickFood-desc'>
                Furniture Store Furny systems handle delivery scheduling and route planning for delivery. Inventory may be located on the showroom floor, in a storeroom or in a separate warehouse. Items are generally one of three types; stock, special order and customize to order. The POS should handle customization options and take deposits.
                </p>
                <ListGroup className='mt-4'>
                  <ListGroupItem className='border-0 ps-0'>
                    <p className='choose__us-title d-flex align-items-center gap-2'>
                      <i className='ri-checkbox-circle-line'></i>Quality Furnitures
                    </p>
                    
                  </ListGroupItem>
                  <ListGroupItem className='border-0 ps-0'>
                    <p className='choose__us-title d-flex align-items-center gap-2'>
                      <i className='ri-checkbox-circle-line'></i>Best Price
                    </p>
                    
                  </ListGroupItem>
                  <ListGroupItem className='border-0 ps-0'>
                    <p className='choose__us-title d-flex align-items-center gap-2'>
                      <i className='ri-checkbox-circle-line'></i>Order from any
                      location
                    </p>
                    
                  </ListGroupItem>
                </ListGroup>
              </div>
            </Col>
          </Row>
        </Container>
      </section>

    

      <section>
        <Container>
          <Row>
            <Col lg='6' md='6'>
              <div className='testimonial'>
                <h5 className='testimonial__subtitle mb-4'>Testimonial</h5>
                <h2 className='testimonial__title mb-40'>
                  What our <span>customers </span>are saying
                </h2>
                <p className='testimonial__desc'>
                We are proud of the things our customers are saying about us, and we’d like to share some of their comments with you
                </p>
                <TestimonialSlider />
              </div>
            </Col>
            <Col lg='6' md='6'>
              <img src={networkImg} alt='testimonial-img' className='w-100' />
            </Col>
          </Row>
        </Container>
      </section>
    </Helmet>
  );
};

export default Home;
